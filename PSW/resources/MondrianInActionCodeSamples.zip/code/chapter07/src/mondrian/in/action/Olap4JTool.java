/*
 * Command line program to interact with Mondrian via OLAP4J.
*/
package mondrian.in.action;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;

import mondrian.rolap.RolapUtil;
import org.apache.log4j.Level;
import org.olap4j.CellSet;
import org.olap4j.OlapConnection;
import org.olap4j.layout.CellSetFormatter;
import org.olap4j.layout.RectangularCellSetFormatter;
import org.olap4j.metadata.Schema;


import java.io.PrintWriter;

/**
 * Main class for querying MDX.
 * @author Bill Back
 */
public class Olap4JTool {

  /**
   * File driver.
   * @param args Command line arguments
   *  [0] => filename of mondrian schema
   *  [1] => mdx query
   * TODO Switch to command line input, e.g. -f and --mdx
   */
  public static void main (String args []) {
    try {

      RolapUtil.MDX_LOGGER.setLevel(Level.DEBUG);
      String filename = args[0];
      //String filename = "/Users/billback/Dropbox/MondrianBook/Tools/AW3.mondrian.xml";
      //String mdx = "SELECT [Measures].[Sales Amount] ON COLUMNS, [Customer].[Gender].Members ON ROWS FROM [InternetSales]";
      String mdxFile = args[1];
      String username = null;
      String password = null;
      try {
        username = args[2];
        password = args[3];
      }
      catch (Exception e) {
        e.printStackTrace();
      }

      String jdbcURL = "jdbc:mysql://localhost:3306/adventure_works_dw";
      String jdbcDriver = "com.mysql.jdbc.Driver";
      OlapConnection olapConnection = Olap4JHelper.createConnection(filename, jdbcURL, jdbcDriver, username, password);

      Schema schema = olapConnection.getOlapSchema();
      System.out.println("Schema: " + schema.getName());

      BufferedReader reader = new BufferedReader(new FileReader(mdxFile));
      String mdx;
      while ((mdx = reader.readLine()) != null) {
        executeQuery(olapConnection, mdx);
      }
      reader.close();

    } catch (Throwable e) {
      e.printStackTrace();
    }
  }

  private static void executeQuery(OlapConnection olapConnection, String mdx) throws Exception{
    System.out.println(mdx);

    // execute query and show results.
    CellSet cellSet = olapConnection.createStatement().executeOlapQuery(mdx);
    CellSetFormatter csf = new RectangularCellSetFormatter(false);
    PrintWriter pw = new PrintWriter(System.out);
    csf.format(cellSet, pw);
    pw.flush();
  }
}
