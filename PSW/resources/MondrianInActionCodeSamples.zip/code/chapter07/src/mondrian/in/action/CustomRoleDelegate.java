package mondrian.in.action;

import mondrian.olap.*;
import org.pentaho.platform.engine.core.system.PentahoSessionHolder;

public class CustomRoleDelegate extends DelegatingRole {

  private String state;
  private static String HIERARCHY_NAME = "Geography";

  public CustomRoleDelegate(Role role) {
    super(((RoleImpl) role).makeMutableClone());
    this.state = (String)PentahoSessionHolder.getSession().getAttribute("USER_STATE_PROVINCE_NAME");
    System.out.println("CustomRoleDelegate: Creating customer role with state == " + state);
  }

  @Override
  public HierarchyAccess getAccessDetails(Hierarchy hierarchy) {
    System.out.println("CustomRoleDelegate: Getting access details for hierarchy " + hierarchy.getQualifiedName());
    HierarchyAccess ha = super.getAccessDetails(hierarchy);
    return (ha == null ? null : new CustomHierarchyAccess(ha));
  }

  protected class CustomHierarchyAccess extends RoleImpl.DelegatingHierarchyAccess {
    public CustomHierarchyAccess(HierarchyAccess ha) {
      super(ha);
      System.out.println("CustomHierarchyAccess: Creating customer hierarchy access class for hierarchy " + ha);
    }

    public Access getAccess(Member member) {
      System.out.println("CustomHierarchyAccess: checking access to member " + member.getQualifiedName());
      return CustomRoleDelegate.this.getAccess(member, hierarchyAccess.getAccess(member));
    }
  }

  @Override
  public Access getAccess(Hierarchy hierarchy) {
    System.out.println("CustomRoleDelegate: checking access to hierarchy " + hierarchy.getQualifiedName());
    return role.getAccess(hierarchy);
  }

  @Override
  public Access getAccess(Member member) {
    System.out.println("CustomRoleDelegate: checking access to member " + member.getQualifiedName());
    return getAccess(member, role.getAccess(member));
  }

  protected Access getAccess(Member member, Access access) {
    System.out.println("CustomRoleDelegate: checking access to member " + member.getQualifiedName() + " with previous access of " + access);

    String memberHierarchyName = member.getHierarchy().getName();
    System.out.println("\tlooking at hierarchy " + memberHierarchyName);
    if (memberHierarchyName.contains(HIERARCHY_NAME)) {
      System.out.println("\tchecking for state " + state + " against " + member.getName());
      if (member.getName().equalsIgnoreCase(this.state)) {
        System.out.println("\t\tequals, so grant access");
        return Access.ALL;
      }

      System.out.println("\tchecking ancestors");
      for (Member mem : member.getAncestorMembers()) {
        System.out.println("\t\tcomparing to " + mem.getName());
        if (mem.getName().equalsIgnoreCase(this.state)) {
          System.out.println("\t\tequals, so grant access");
          return Access.ALL;
        }
      }

      Access acc = (access == Access.CUSTOM) ? access : Access.NONE;
      System.out.println("\tfalling through with access of " + acc);
      return acc;
    }

    System.out.println("\treturning normal access");
    return access;
  }

  @Override
  public Access getAccess(Level level) {
    return role.getAccess(level);
  }

}
