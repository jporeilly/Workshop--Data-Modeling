package mondrian.in.action;

import mondrian.i18n.LocalizingDynamicSchemaProcessor;
import mondrian.olap.Util;
import org.pentaho.platform.api.engine.IPentahoSession;
import org.pentaho.platform.engine.core.system.PentahoSessionHolder;

import java.io.InputStream;
import java.util.regex.PatternSyntaxException;

public class RegionDynamicSchemaProcessor
    extends LocalizingDynamicSchemaProcessor
    implements mondrian.spi.DynamicSchemaProcessor {

  public RegionDynamicSchemaProcessor() {
    super();
    System.out.println("DSP: Creating the DSP from LDSP - please work!");
  }

  @Override
  public String filter(String schemaUrl, Util.PropertyList connectInfo, InputStream stream) throws Exception {

    String schema = super.filter(schemaUrl, connectInfo, stream); // let the parent have first dibs.

    System.out.println("DSP: modifying the schema.");
    IPentahoSession session = PentahoSessionHolder.getSession();
    String region = (String)session.getAttribute("USER_REGION_CODE");
    System.out.println("DPS:\tregion ==> " + region);

    if (region == null) {
      System.out.println("DSP:\tWARNING:  No user region specified.");
    }
    else {
      try {
        schema = schema.replaceAll("%USER_REGION%", region);
      }
      catch (PatternSyntaxException pse) {
        // Thrown if the pattern to be replaced is bad.  Log and press.
        pse.printStackTrace();
      }
    }

    System.out.println(schema);
    return schema;
  }

}
