package mondrian.in.action;

import mondrian.olap.*;
import org.pentaho.platform.plugin.services.connections.mondrian.MDXConnection;

public class CustomMDXConnection extends MDXConnection {

  @Override
  protected void init (Util.PropertyList properties) {
    super.init(properties);
    System.out.println("CustomMDXConnection:  Setting the connection to restrict on States.");
    System.out.println("\tusing this instead of super");
    Connection thisConn = this.getConnection();
    if (thisConn != null) {
      Role authRole = thisConn.getSchema().lookupRole("Authenticated");

      if (authRole != null) {
        System.out.println("\tAssigning custom role.");
        CustomRoleDelegate customRole = new CustomRoleDelegate(authRole);

        thisConn.setRole(customRole);
        setRole(customRole);
      }
    }
    else {
      System.out.println("\tMDX connection is NULL!!");
    }
  }
}
