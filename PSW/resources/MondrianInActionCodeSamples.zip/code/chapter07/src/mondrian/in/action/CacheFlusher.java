package mondrian.in.action;

import mondrian.olap.*;
import mondrian.rolap.RolapSchema;

import java.sql.SQLException;
import java.util.List;

public class CacheFlusher {

  //<start id="cache_flush_all"/>
  public boolean flushAll ()
    throws SQLException, ClassNotFoundException {

    List<RolapSchema> schemas = RolapSchema.getRolapSchemas();
    for (RolapSchema schema : schemas) { //<co id="cfa_get_all_schemas"/>

      CacheControl cacheControl =
        schema.getInternalConnection().getCacheControl(null);
      cacheControl.flushSchema(schema);//<co id="cfa_flush_schema"/>

      cacheControl.flushSchemaCache();//<co id="cfa_flush_schema_cache"/>
    }
    return true;
  }
  //<end id="cache_flush_all"/>

  //<start id="cache_flush_cube"/>
  public boolean flushCube(String schemaName, String cubeName) {
    List<RolapSchema> schemas = RolapSchema.getRolapSchemas();
    for (RolapSchema schema : schemas) {
      if (schema.getName().equals(schemaName)) {//<co id="cfa_cube_find_schema"/>
        CacheControl cacheControl =
          schema.getInternalConnection().getCacheControl(null);
        for (Cube cube : schema.getCubes()) {
          if (cube.getName().equals(cubeName)) {//<co id="cfa_cube_find_cube"/>
            cacheControl.flush(
              cacheControl.createMeasuresRegion(cube));//<co id="cfa_cube_flush_cube"/>
            return true;
          }
        }
      }
    }
    return false;
  }
  //<end id="cache_flush_cube"/>

  //<start id="cache_flush_cube_region"/>
  public boolean flushCubeRegion (
    String schemaName,
    String cubeName,
    String [] members
    ) {

    // Is there a way to just get a particular schema
    // rather than look through the list?
    for (RolapSchema schema : RolapSchema.getRolapSchemas()) {
      if (schemaName.equals(schema.getName())) {//<co id="cfcr_find_schema"/>
        Cube cube = schema.lookupCube(cubeName, true);//<co id="cfcr_find_cube"/>
        SchemaReader schemaReader = cube.getSchemaReader(null);
        CacheControl cacheControl =//<co id="cfcr_get_cache_control"/>
          schema.getInternalConnection().getCacheControl(null);
        CacheControl.CellRegion [] regions =//<co id="cfcr_cell_regions"/>
          new CacheControl.CellRegion[members.length + 1];
        regions[0] = cacheControl.createMeasuresRegion(cube);//<co id="cfcr_measure_region"/>
        int size = 1;
        for (String memberName : members) {
          Member member =//<co id="cfcr_find_member"/>
            schemaReader.getMemberByUniqueName(
              memberNameToSegmentList(memberName),true);
          regions[size++] =//<co id="cfcr_create_member_region"/>
            cacheControl.createMemberRegion(member, true);
        }
        CacheControl.CellRegion xregion =//<co id="cfcr_create_crossjoin"/>
          cacheControl.createCrossjoinRegion(regions);
        cacheControl.flush(xregion);//<co id="cfcr_flush_region"/>
        return true;
      }
    }
    return false;

  }
  //<end id="cache_flush_cube_region"/>

  private List<Id.Segment> memberNameToSegmentList (String memberName) {
    // Require that the member name is in the form [xxx].[xxx].[xxx].  So simply split on the period and
    // then strip the [] from the name.
    String [] parts = memberName.split("\\.");
    for (int cnt = 0; cnt < parts.length; cnt++) {
      parts[cnt] = parts[cnt].substring(1, parts[cnt].length() - 1);
    }
    return Id.Segment.toList(parts);
  }

  private String arrayToString (String [] array) {
    String res = "[";
    boolean first = true;
    for (int cnt = 0; cnt < array.length; cnt++) {
      if (!first) {
        res += ", ";
      }
      first = false;
      res += array[cnt];
    }
    res += "]";
    return res;
  }
}
