package mondrian.in.action;

import org.olap4j.OlapConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Contains methods that help working with OLAP4J.
 * @author Bill Back
 */
public class Olap4JHelper {

  public static synchronized OlapConnection createConnection (String schemaFile,
                                                              String jdbcURL,
                                                              String jdbcDriver,
                                                              String username,
                                                              String password)
    throws ClassNotFoundException, SQLException {

    Class.forName("mondrian.olap4j.MondrianOlap4jDriver");

    String cnxURL = "jdbc:mondrian:Jdbc=" + jdbcURL + ";";
    cnxURL += "JdbcDrivers=" + jdbcDriver + ";";
    if (username != null) {
      cnxURL += "JdbcUser=" + username + ";";
    }
    if (password != null) {
      cnxURL += "JdbcPassword=" + password + ";";
    }
    cnxURL += "Catalog=file:" + schemaFile + ";";

    System.out.println("cnxURL ==> " + cnxURL);

    Connection connection = DriverManager.getConnection(cnxURL);
    OlapConnection olapConnection = connection.unwrap(OlapConnection.class);

    return olapConnection;
  }
}
