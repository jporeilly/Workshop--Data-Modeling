//<start id="xmla4js_get_service_url"/>
function getServiceURL () {
  var baseURL  = queryFormElement("serverURL").val();//<co id="post_message_get_parameters>"/>
  var userid   = queryFormElement("userId").val();
  var password = queryFormElement("password").val();
  
  if (baseURL == '') { //<co id="post_message_check_URL"/>
    alert ('Error: you must set the server URL prior to any calls');
    return;
  }
  
  var url = baseURL + "?"; //<co id="post_message_check_user"/>
  if (userid != '') { url += "userid=" + userid + "&";}
  if (password != '') {url += "password=" + password;}
  
  return url;
}
//<end id="xmla4js_get_service_url"/>

//<start id="xmla4js_find_query_form_element"/>
function queryFormElement(elementName) {
  var el = $("#queryForm").find('input[name="' + elementName + '"]');
  return el;
}
//<end id="xmla4js_find_query_form_element"/>

//<start id="xmla4js_set_catalog_select"/>
function setCatalogSelect() {
  var html = "";
  for (var catalogName in catalogsAndCubes) {
    var catalog = catalogsAndCubes[catalogName];
    var cubes       = catalog.cubes;
    
    html += "<option value='" + catalogName + "'>" + 
               catalogName + " - " + cubes.join(" | ") + 
            "</option>";
  }
  $("#catalogSelect").html(html);  
}
//<end id="xmla4js_set_catalog_select"/>

//<start id="xmla4js_split_field"/>
function splitField (field) {
  var fieldNames = [];
  
  // strip initial and final []
  var f = field.substr(1, field.length-2);
  var fieldTokens = f.split("].[");
  // get the odd ones since they have iteresting data.
  for (var fcnt = 1; fcnt < fieldTokens.length; fcnt += 2) {
    fieldNames[fieldNames.length] = fieldTokens[fcnt];
  }
  return fieldNames;
}
//<end id="xmla4js_split_field"/>

// return an array of the same width as the data to be easily printed.
// has the format of:
//   "[dimension].[level].[MEMBER_CAPTION]" 
//   ....
//   [Hierarchy].[Value].[Hierarchy].[Value]....
//   ....
// The length of the fieldNames header is the width of each row in the array to return.
//<start id="xmla4js_parse_field_names"/>
function parseFieldNames (fieldNames) {
  var rowHeaders = [];
  var colHeaders = [];
  
  for (var fcnt = 0; fcnt < fieldNames.length; fcnt++) {//<co id="xmla4js_get_headers"/>
    if (fieldNames[fcnt].indexOf("MEMBER_CAPTION") != -1) {//<co id="xmla4js_row_header"/>
      rowHeaders[rowHeaders.length] = splitField (fieldNames[fcnt]);
    }
    else {//<co id="xmla4js_column_headers"/>
      colHeaders[colHeaders.length] = splitField (fieldNames[fcnt]);
    }
  }
  
  var nbrColHeaderLevels = colHeaders[0].length;//<co id="xmla4js_nbr_column_headers"/>
  var headers = [];//<co id="xmla4js_headers"/>
  
  for (hcnt = 0; hcnt < nbrColHeaderLevels; hcnt++) {
    headers[headers.length] = [];//<co id="xmla4js_new_header_row"/>
    
    var lastRow = (hcnt == nbrColHeaderLevels - 1);
    for (rhcnt = 0; rhcnt < rowHeaders.length; rhcnt++) {//<co id="xmla4js_add_row_headers"/>
      if (lastRow) {
        headers[hcnt].push(rowHeaders[rhcnt][0]);//<co id="xmla4js_but_only_on_last_row"/>
      }
      else {
        headers[hcnt].push("");
      }
    }
    
    for (ccnt = 0; ccnt < colHeaders.length; ccnt++) {//<co id="xmla4js_add_column_headers"/>
      headers[hcnt].push(colHeaders[ccnt][hcnt]);
    }
  }
  
  return headers;
}
//<end id="xmla4js_parse_field_names"/>

//<start id="xmla4js_xmla_variables"/>
var xmla;              //<co id="xmla4js_xmla_object"/>
var datasource;        //<co id="xmla4js_datasource"/>
var catalogsAndCubes;  //<co id="xmla4js_catalogs_and_cubes"/>
//<end id="xmla4js_xmla_variables"/>

//<start id="xmla4js_document_ready"/>
$(document).ready(function() {

  //<start id="xmla4js_discover_button_onclick"/>
  queryFormElement("discoverButton").click(function() {
    xmla = new Xmla({url: getServiceURL()});

    datasource = xmla.discoverDataSources().fetchAsObject();//<co id="xmla4js_discover_datasources"/>
    var catalogs = xmla.discoverDBCatalogs().fetchAllAsObject();//co id="xmla4js_discover_catalogs"/>

    catalogsAndCubes = {}; // clear any previous.

    for (var cnt = 0; cnt < catalogs.length; cnt++) {//<co id="xmla4js_for_each_catalog"/>
      var catalogName = catalogs[cnt].CATALOG_NAME;
      var cubesRS = xmla.discoverMDCubes({//<co id="xmla4js_discover_cubes"/>
        properties : {DataSourceInfo : datasource.DataSourceInfo, 
                      Catalog : catalogName},
        restrictions : {CATALOG_NAME : catalogName}
      });

      var cubes = cubesRS.fetchAllAsObject();
      for (var cubeCnt = 0; cubeCnt < cubes.length; cubeCnt++) {//<co id="for_each_cube"/>
        var cubeName = cubes[cubeCnt].CUBE_NAME;
        var catalog = catalogsAndCubes[catalogName];
        if (catalog == null) { 
          catalog = new Object();//<co id="xmla4js_new_catalog"/>
          catalog.catalogName = catalogName;
          catalog.cubes = new Array();
          catalogsAndCubes[catalogName] = catalog;
        }
        catalog.cubes.push(cubeName);//<co id="xmla4js_add_cube_to_catalog"/>
      }
    }
    setCatalogSelect();//<co id="xmla4js_update_cube_select"/>
    
  });  
  //<end id="xmla4js_discover_button_onclick"/>

  //<start id="xmla4js_query_button_onclick"/>
  queryFormElement("queryButton").click(function() {//<co id="xmla4js_get_parameters"/>
    var mdxQuery = $("#queryForm").find('textarea[name=mdxQuery]').val();
    var dataSourceInfo = datasource.DataSourceInfo;
    var catalog = catalogsAndCubes[$("#catalogSelect").val()].catalogName;

    if (mdxQuery == "") {
      alert("Error: No MDX query specified.");
      return;
    }
    
    var resultsRS = xmla.executeTabular({ statement : mdxQuery, //<co id="xmla4js_execute_query"/>
      properties : {
        DataSourceInfo : dataSourceInfo,
        Catalog : catalog
      }
    });

    var fieldNames = resultsRS.getFieldNames();//<co id="xmla4js_get_field_name"/>
    var headers = parseFieldNames(fieldNames);
    $("#results tr").remove();
    for (var hcnt = 0; hcnt < headers.length; hcnt++) {//<co id="xmla4js_add_headers"/>
      var row = "<tr>";
      var h = headers[hcnt];
      for (var ccnt = 0; ccnt < h.length; ccnt++) {
        row += "<th>" + h[ccnt] + "</th>";
      }
      row += "</tr>";
      $("#results > tbody:last").append(row);
    }
    
    var resArray = resultsRS.fetchAllAsArray();//<co id="xmla4js_get_data"/>
    for (var rcnt = 0; rcnt < resArray.length; rcnt++) {//<co id="xmla4js_add_data"/>
      row = "<tr>";
      var r = resArray[rcnt];
      for (var ccnt = 0; ccnt < r.length; ccnt++) {
        row += "<td>" + r[ccnt] + "</td>";
      }
      row += "</tr>";
      $("#results > tbody:last").append(row);
    }
  });  
  //<end id="xmla4js_query_button_onclick"/>

});
//<end id="xmla4js_document_ready"/>